This package contains the Active Calendar Project, an XHTML calendar generator PHP class set.

The source code can be found at source/
The class documentation is under doc/ (english: doc_en.html - mostly updated)

Run the index.php on your server first to get a project overview.
The examples.php is an index of the example scripts listed under data/

Support, feature requests and bug reports please at : http://www.micronetwork.de/activecalendar/

Giorgos Tsiledakis

